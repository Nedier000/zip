from ..enums import ClassIDType

from . import SerializedFile
from .. import classes
from ..classes.Object import NodeHelper
from ..streams import EndianBinaryReader, EndianBinaryWriter
from ..helpers import TypeTreeHelper
from ..helpers.Tpk import get_typetree_nodes
from ..exceptions import TypeTreeError


class ObjectReader:
    byte_start: int
    byte_size: int
    type_id: int
    class_id: int
    type: ClassIDType
    path_id: int
    # serialized_type: SerializedType
    _read_until: int

    # saves where the parser stopped
    # in case that not all data is read
    # and the obj.data is changed, the unknown data can be added again

    def __init__(self, assets_file, reader: EndianBinaryReader):
        self.assets_file = assets_file
        self.reader = reader
        # None means "unmodified". Empty bytes is a valid replacement payload.
        self.data = None
        self._in_object_reader = False
        self._object_read_depth = 0
        self.version = assets_file.version
        self.version2 = assets_file.header.version
        self.platform = assets_file.target_platform
        self.build_type = assets_file.build_type

        header = assets_file.header
        types = assets_file.types

        # AssetStudio ObjectInfo init
        if assets_file.big_id_enabled:
            self.path_id = reader.read_long()
        elif header.version < 14:
            self.path_id = reader.read_int()
        else:
            reader.align_stream()
            self.path_id = reader.read_long()

        if header.version >= 22:
            self.byte_start_offset = (self.reader.real_offset(), 8)
            self.byte_start = reader.read_long()
        else:
            self.byte_start_offset = (self.reader.real_offset(), 4)
            self.byte_start = reader.read_u_int()

        self.byte_start += header.data_offset
        self.byte_header_offset = header.data_offset
        self.byte_base_offset = self.reader.BaseOffset

        self.byte_size_offset = (self.reader.real_offset(), 4)
        self.byte_size = reader.read_u_int()

        self.type_id = reader.read_int()

        if header.version < 16:
            self.class_id = reader.read_u_short()
            self.serialized_type = None
            for typ in types:
                if typ.class_id == self.type_id:
                    self.serialized_type = typ
                    break
        else:
            typ = types[self.type_id]
            self.serialized_type = typ
            self.class_id = typ.class_id

        self.type = ClassIDType(self.class_id)

        if header.version < 11:
            self.is_destroyed = reader.read_u_short()

        if 11 <= header.version < 17:
            script_type_index = reader.read_short()
            if self.serialized_type:
                self.serialized_type.script_type_index = script_type_index

        if header.version == 15 or header.version == 16:
            self.stripped = reader.read_byte()

    def write(
        self, header, writer: EndianBinaryWriter, data_writer: EndianBinaryWriter
    ):
        if self.assets_file.big_id_enabled:
            writer.write_long(self.path_id)
        elif header.version < 14:
            writer.write_int(self.path_id)
        else:
            writer.align_stream()
            writer.write_long(self.path_id)

        if self.data is not None:
            data = self.data
            # in some cases the parser doesn't read all of the object data
            # games might still require the missing data
            # so following code appends the missing data back to edited objects
            # -> following solution has let to some problems, so it will be removed for now
            # if self.type != ClassIDType.MonoBehaviour:
            #     end_pos = self.byte_start + self.byte_size
            #     if self._read_until and self._read_until != end_pos:
            #         self.reader.Position = self._read_until
            #         data += self.reader.read_bytes(end_pos - self._read_until)
        else:
            self.reset()
            data = self.reader.read(self.byte_size)

        if header.version >= 22:
            writer.write_long(data_writer.Position)
        else:
            writer.write_u_int(data_writer.Position)

        writer.write_u_int(len(data))
        data_writer.write(data)

        writer.write_int(self.type_id)

        if header.version < 16:
            writer.write_u_short(self.class_id)

        if header.version < 11:
            writer.write_u_short(self.is_destroyed)

        if 11 <= header.version < 17:
            writer.write_short(self.serialized_type.script_type_index)

        if header.version == 15 or header.version == 16:
            writer.write_byte(self.stripped)

    def set_raw_data(self, data):
        self.data = bytes(data)
        self.byte_size = len(self.data)
        if self.assets_file:
            self.assets_file.mark_changed()

    @property
    def container(self):
        return (
            self.assets_file._container[self.path_id]
            if self.path_id in self.assets_file._container
            else None
        )

    @property
    def Position(self):
        return self.reader.Position

    @Position.setter
    def Position(self, pos):
        self.reader.Position = pos

    def reset(self):
        self.reader.Position = 0 if self._in_object_reader else self.byte_start

    def _begin_object_read(self):
        """Use a bounded zero-copy reader for one serialized object.

        Object parsers used to share the complete assets-file reader.  A stale
        cursor or a parser/layout mismatch could therefore read into following
        objects (and, for bogus array sizes, allocate enormous amounts of
        memory).  A memoryview slice keeps this fast while enforcing the
        object's declared byte boundary.
        """
        source = self.reader
        if self._object_read_depth:
            # MonoBehaviour's class parser asks for its complete typetree while
            # the outer bounded object reader is still active.  Clone that
            # already-bounded view instead of applying the absolute
            # ``byte_start`` a second time.  The previous implementation
            # interpreted the 4.6 MB file offset inside a 1 KB object view and
            # consequently rejected valid Unity 2022 MonoBehaviours.
            local = EndianBinaryReader(
                source.bytes,
                endian=source.endian,
                offset=source.BaseOffset,
            )
            self.reader = local
            self._object_read_depth += 1
            self._in_object_reader = True
            return source, local
        if self.data is not None:
            local = EndianBinaryReader(
                self.data,
                endian=source.endian,
                offset=source.BaseOffset + self.byte_start,
            )
            self.reader = local
            self._object_read_depth += 1
            self._in_object_reader = True
            return source, local
        end = self.byte_start + self.byte_size
        if self.byte_start < 0 or self.byte_size < 0 or end > source.Length:
            raise ValueError(
                f"Object {self.path_id} range [{self.byte_start}, {end}) "
                f"is outside the {source.Length}-byte assets file"
            )
        source.Position = self.byte_start
        data = source.read_bytes(self.byte_size)
        if len(data) != self.byte_size:
            raise EOFError(
                f"Object {self.path_id} is truncated: expected "
                f"{self.byte_size} bytes, got {len(data)}"
            )
        local = EndianBinaryReader(
            data,
            endian=source.endian,
            offset=source.BaseOffset + self.byte_start,
        )
        self.reader = local
        self._object_read_depth += 1
        self._in_object_reader = True
        return source, local

    def _end_object_read(self, source, local):
        self._read_until = self.byte_start + local.Position
        self.reader = source
        self._object_read_depth = max(0, self._object_read_depth - 1)
        self._in_object_reader = self._object_read_depth > 0

    def peek_name(self, default=None):
        """Read the leading ``m_Name`` without parsing the whole object."""
        named_types = {
            "AnimationClip", "AnimatorController", "AssetBundle", "AudioClip",
            "Avatar", "Font", "Material", "Mesh", "MonoScript",
            "RuntimeAnimatorController", "Shader", "Sprite", "SpriteAtlas",
            "TextAsset", "Texture2D", "VideoClip",
        }
        if self.type.name not in named_types:
            return default
        source, local = self._begin_object_read()
        try:
            name = local.read_aligned_string()
            return name or default
        except (EOFError, ValueError, UnicodeError):
            return default
        finally:
            self._end_object_read(source, local)

    def read(self, return_typetree_on_error: bool=True):
        cls = getattr(classes, self.type.name, None)

        obj = None
        parse_error = None
        source, local = self._begin_object_read()
        try:
            if cls:
                obj = cls(self)
        except Exception as e:
            parse_error = e
        finally:
            self._end_object_read(source, local)

        if parse_error is not None:
            if return_typetree_on_error:
                print(f"Error during the parsing of object {self.path_id}")
                print(parse_error)
                print("Returning the typetree")
            else:
                raise parse_error
        if not obj:
            typetree = self.read_typetree()
            if typetree:
                obj = NodeHelper(typetree, self.assets_file)
        return obj

    def get(self, key, default=None):
        return getattr(self, key, default)

    def __getattr__(self, item: str):
        # During copy.copy()/object reconstruction, Python may probe attributes
        # before ``reader`` has been installed.  Accessing self.reader normally
        # re-enters __getattr__ and can recurse until RecursionError.
        try:
            reader = object.__getattribute__(self, "reader")
        except AttributeError:
            raise AttributeError(item) from None
        try:
            return getattr(reader, item)
        except AttributeError:
            raise AttributeError(item) from None

    def __copy__(self):
        # ObjectReader copies used for adding a serialized object should retain
        # the same assets_file/reader metadata but own an independent attribute
        # dictionary.  Avoid copy's generic reconstruction probes, which can
        # recurse through __getattr__ on partially initialized instances.
        cls = type(self)
        clone = cls.__new__(cls)
        clone.__dict__.update(object.__getattribute__(self, "__dict__"))
        return clone

    def __repr__(self):
        return "<%s %s>" % (self.__class__.__name__, self.type.name)

    ###################################################
    #
    #           Typetree Stuff
    #
    ###################################################

    def dump_typetree(self, nodes: list = None) -> str:
        source, local = self._begin_object_read()
        try:
            sb = []
            nodes = self.get_typetree_nodes(nodes)
            TypeTreeHelper.read_typetree_str(sb, nodes, self)
            return "".join(sb)
        finally:
            self._end_object_read(source, local)

    def dump_typetree_structure(self) -> str:
        return TypeTreeHelper.dump_typetree(self.get_typetree_nodes())

    def get_typetree_nodes(self, nodes: list = None) -> list:
        if nodes:
            return nodes
        
        if self.serialized_type:
            nodes = self.serialized_type.nodes
        if not nodes:
            nodes = get_typetree_nodes(self.class_id, self.version)
            # AOV's modern Mesh payload includes an extra UInt32 before the
            # compression flags. The class parser already reads m_IsInUse;
            # stock TPK fallback nodes must describe the same byte layout.
            # Never alter an embedded asset-specific TypeTree or the TPK cache.
            if self.class_id == 43 and self.version >= (2019,):
                nodes = list(nodes)
                position = next((index for index, node in enumerate(nodes)
                                 if node.m_Level == 1 and node.m_Name == "m_MeshCompression"), None)
                if position is not None and not any(node.m_Name == "m_IsInUse" for node in nodes):
                    nodes.insert(position, TypeTreeHelper.TypeTreeNode(
                        m_Type="UInt32", m_Name="m_IsInUse", m_Level=1,
                        m_ByteSize=4, m_Index=position, m_Version=1, m_MetaFlag=0,
                    ))
        if not nodes:
            raise TypeTreeError("There are no TypeTree nodes for this object.")
        return nodes

    def read_typetree(self, nodes: list = None) -> dict:
        source, local = self._begin_object_read()
        try:
            nodes = self.get_typetree_nodes(nodes)
            return TypeTreeHelper.read_typetree(nodes, self)
        finally:
            self._end_object_read(source, local)

    def save_typetree(
        self, tree: dict, nodes: list = None, writer: EndianBinaryWriter = None
    ):
        nodes = self.get_typetree_nodes(nodes)
        if not writer:
            writer = EndianBinaryWriter(endian=self.reader.endian)
        writer = TypeTreeHelper.write_typetree(tree, nodes, writer)
        data = writer.bytes
        self.set_raw_data(data)
        return data

    def get_raw_data(self) -> bytes:
        if self.data is not None:
            return self.data
        pos = self.Position
        self.reset()
        ret = self.reader.read_bytes(self.byte_size)
        self.Position = pos
        return ret

    def set_raw_data(self, data):
        self.data = bytes(data)
        self.byte_size = len(self.data)
        if self.assets_file:
            self.assets_file.mark_changed()
